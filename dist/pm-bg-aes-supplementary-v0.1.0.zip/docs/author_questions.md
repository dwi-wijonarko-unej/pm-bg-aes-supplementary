# Author Questions — Evidence and pending decisions

Status: **MIT license choice confirmed by the repository maintainer/user on
2026-10-08 (Q6); other questions remain pending where noted**. The local
demonstration pipeline does not establish reproduction of the original
manuscript experiments or permission to redistribute inputs.
Evidence below is from the [2026-10-08 audit](evidence_audit.md).

## Q1. Canonical implementation and original measurements

`PM_BG_+_AES_(works)_ori.ipynb` cell 1 remains the selected archival
implementation, pending confirmation that it produced Tables 3/7. The
additional `PM-BG + AES (works)_ori.ipynb` has identical source/output to the
root ori notebook but different metadata; this is not an independent run.

- Table 3 matches saved stdout from ori cell 1 exactly: 0.0070 s,
  14.27 MiB/s, 1125.57 KB, 99.9%, and 104300 → 104267 bytes. Its input
  `FileAttachment.pdf_encrypted` is missing; `COMNET-S-26-08200.pdf` is also
  missing. Matching saved output is not a fresh reproduction.
- All Table 7 rows match
  `results/analysis result/2. File TXT - Paper PM-BG + AES_ori.txt` (identical
  content in `File TXT - Paper PM-BG + AES_ori.md` in that directory).
- Original repetition counts and execution environment remain unknown.
  DEMO-001..DEMO-011 use five repetitions and are new demonstrations, not
  evidence of the original experimental protocol.

Please confirm the producing cell/commit, original input hashes, timing and
throughput definitions, repetitions, and hardware/software environment.

## Q2. Original datasets F1..F9: local evidence, rights pending

Original/encrypted/decrypted files are available locally under
`results/analysis result/File 1-MP4` through `File 9-EXE`. All nine original
versus decrypted SHA-256 comparisons match (sizes and paths in
`docs/dataset_evidence.csv`). All 27 files were untracked at
the audit date; local presence and original–decrypted file equality do not establish
provenance, manuscript identity, or redistribution rights.

Please confirm each file's provenance, original experiment mapping, hashes,
sizes, ownership/license, and redistribution permission. The Table 3 input
and COMNET file noted in Q1 remain missing. Do not release any of these
files solely because they are available locally.

## Q3. Shift-128 definition and Figure 7 mapping

The additional `PM-BG + AES (works).ipynb` implements Shift128 as ±128
modulo 256. However, it uses a different complete-graph/unimodular/AES-128
whole-payload pipeline, not the selected permutation/AES-256 residual-tail
pipeline. Its existence does not establish the canonical implementation's
Figure 7 behavior.

For F9, N = 5,423,488 and n = 32 give zero residual; its relationship to
Figure 7 remains unclear. Please identify the intended pipeline, input,
residual definition, and exact Figure 7 generation procedure.

## Q4. UCEF-Code Security Analyzer

Reports are locally available as `1. [01.09.2026] Analisis Algoritma.docx`
(UCEF v1.0, score 60) and
`3. [01.09.2026] Analisis Keamanan Data.docx` (v3.0). The analyzer tool,
configuration, CSV/XLSX exports, and figure-generation artifacts are missing.
These reports are evidence of reported analysis, not an independently
reproduced score.

Please supply the tool/version, configuration, inputs and hashes, exports,
and figure workflow, or confirm that these results must remain
report-only. We will not build a look-alike scorer.

## Q5. Equations, derivations, and Tables 8/9 assumptions

OMML equation text has now been extracted. Formula availability must not be
inferred from earlier blank plain-text extraction. Original derivations and
assumptions for Tables 8/9 remain pending, including key-space counting and
brute-force rate assumptions. Please confirm these derivations, units,
constraints, and source calculations; extracted equations alone do not
validate the numerical or security claims.

## Q6. License choice — closed: MIT confirmed; artifact rights review remains

On 2026-10-08 the repository maintainer/user explicitly confirmed:
**"Lisensi kami gunakan MIT"**. This closes the repository license-choice
question: MIT applies to repository-owned code, documentation, and synthetic
demonstration data. This records the maintainer/user's confirmation, not
verified approval from all manuscript authors or every rights holder.

The earlier pending-license/no-rights finding is historical and superseded
by this MIT confirmation. MIT does not automatically grant rights to
third-party F1..F9 files (including encrypted/decrypted copies), the manuscript,
or UCEF/supplied reports. Their ownership, permissions, and per-artifact
redistribution review remain pending. License choice does not confirm
experimental provenance, contributors, release scope, or publication approval
(see Q2, Q7, and Q9).

## Q7. Authorship vs. contributorship

Manuscript authors (9 names) are recorded from the draft; software
contributors may differ. Please confirm the contributor list, corresponding
contact, affiliations/ORCIDs (optional), and exact citation title for
`CITATION.cff`/`.zenodo.json` (both draft). Contributor confirmation and
approval remain pending.

## Q8. "AI selector" terminology

The selected code uses a deterministic rule table (file size × entropy
thresholds), not a trained ML model. May we describe it as "rule-based
adaptive selector (called 'AI selector' in the notebook)", or is there a
trained model behind the thresholds that should be archived?

## Q9. Release approval and artifact inclusion

The repository manager can organize evidence, but technical confirmation must
come from the developer/experimenter and permissions from the relevant rights
holders. Record each answer with responsible person, evidence path, date,
status (known / pending / unavailable), and publication permission. A missing
artifact may be closed as unavailable with a documented limitation, not as
reproduced. Do not relabel a new rerun as an original historical result.

Please explicitly approve the release scope, contributors,
per-file inclusion allowlist, repository/deposit destination, and version
before any public push/release/deposit. External publication has not been
checked; no verified public URL or DOI is available from this audit.
MIT license choice is confirmed in Q6, but does not close these release gates.

`scripts/build_release.py` currently collects all `results/` without rights
gating. Its assertion rejects DOCX and `Zone.Identifier` files, but deleting
those alone could still package restricted data. An explicit inclusion
allowlist/filter and privacy/password review of notebook outputs and logs
are required before rebuilding. Existing experimental password values must
not be copied into public documentation or artifacts.

The existing ZIP remains an older local candidate: its manifest has no
`results/analysis result/` folder. The earlier wording-only cleanup changed
three archived documents and their checksums without adding evidence files.
The parent-managed archive was also selectively updated for MIT wording;
this docs-only change does not edit the archive or its metadata. Selective
updates are not a full rebuild or synchronization with all current docs.
README and its package-description copy describe the audited local evidence.
Review an approved candidate before release; these edits imply neither
provenance nor publication approval.

## Q10. Password policy

The selected notebook prompts say "digits only" but do not validate digits
(any string works via `str(password2)`). Is that restriction intended, or
should the artifact document actual behavior (any string, UTF-8 encoded)?
Policy confirmation does not replace the output/log privacy review in Q9.

## Q11. Statistical input and sampling provenance

For encrypted F9, the report gives entropy 6.910008, chi-square
12468952.264704, and adjacent r ≈ 0.000917. The current full encrypted file
gives entropy 6.910783258, chi-square 33766723.685766, and adjacent r
0.289727746. These are not matching measurements.

Please provide the exact input hashes, sampled segment/length, header
handling, preprocessing, and statistical definitions needed to explain the
difference. Do not substitute the full-file results for the reported
experiment or claim the report has been reproduced.

## Q12. Divergence and attack claims

Divergence 89.417345% and bit difference 42.830370% match an original-versus-
ciphertext **prefix** comparison including the 12-byte ciphertext header.
This is not a controlled avalanche experiment. Differential and
known-plaintext attacks (KPA) were not executed; chosen-plaintext attack
(CPA) resistance was not demonstrated in the available UCEF report.

Please confirm the intended interpretation and provide controlled
experiments/protocols for any retained avalanche, differential, KPA, or CPA
claims. Otherwise distinguish report claims from demonstrated evidence.

## Ready-to-send team request (Indonesian)

Mohon konfirmasi hasil audit 8 Oktober 2026: pemetaan kode/input untuk
Tabel 3/7 dan Gambar 7, hash serta hak redistribusi F1–F9, lingkungan dan
pengulangan eksperimen asli, tool/config/export UCEF, sampling statistik
F9, serta derivasi/asumsi Tabel 8/9. Mohon juga konfirmasi interpretasi
metrik divergence (bukan uji avalanche terkontrol), bukti klaim serangan,
kontributor, dan persetujuan rilis beserta daftar file yang boleh
disertakan. Pilihan lisensi MIT telah dikonfirmasi pengelola repositori/user
pada 8 Oktober 2026 ("Lisensi kami gunakan MIT") untuk kode, dokumentasi,
dan data demo sintetis milik repositori, bukan konfirmasi seluruh penulis.
Hak atas F1–F9, manuskrip, dan laporan UCEF tetap perlu ditinjau per artefak;
MIT tidak mengonfirmasi provenance atau mengizinkan publikasi. Poin lain
masih menunggu konfirmasi; jangan kirim password/kunci melalui dokumen publik.
