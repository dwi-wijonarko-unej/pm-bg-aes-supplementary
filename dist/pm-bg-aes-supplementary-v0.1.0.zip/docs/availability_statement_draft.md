# Data Availability — Conditional Draft Statements

These are planning drafts, not assertions of publication or approved
availability. The [2026-10-08 evidence audit](evidence_audit.md) establishes
local evidence only; external publication was not checked. On 2026-10-08
the repository maintainer/user confirmed "Lisensi kami gunakan MIT". MIT
applies to repository-owned code, documentation, and synthetic demonstration
data; this is not verified approval from all authors. Provenance, per-artifact
third-party redistribution rights, contributors, and release approval remain
pending. MIT does not automatically cover F1..F9, the manuscript, or UCEF/
supplied reports, and does not approve provenance or publication. Use a
statement only after its conditions are satisfied and verified URLs/version/DOI
are supplied. The code-license template value (`CODE_LICENSE`) is MIT.

## A. Code-only availability (if only code is approved)

> Subject to release approval, code-provenance confirmation, and privacy
> review, the selected repository-owned archival code would be released under
> MIT at [GITHUB_REPOSITORY_URL], version [RELEASE_VERSION], with an archive
> at [ZENODO_VERSION_DOI]. Original
> experiment inputs and restricted reports would not be redistributed.
> Selection of this code does not establish reproduction of all manuscript
> results. [AUTHOR CONFIRMATION REQUIRED: code provenance, contributors,
> approved inclusion list, release approval, and verified publication identifiers.]

## B. Code plus demonstration dataset (if approved)

> Subject to release approval, provenance/contributor confirmation, an explicit
> inclusion allowlist, and privacy review, the selected repository-owned
> archival code and MIT-licensed synthetic
> demonstration data (DEMO-001..DEMO-011), together with approved local
> measurements, would be released at [GITHUB_REPOSITORY_URL], version
> [RELEASE_VERSION], with an archive at [ZENODO_VERSION_DOI]. Repository-owned
> code/docs/demo data would be under MIT. Demonstration inputs would be
> identified by SHA-256 in `data/manifest.csv`. These are new local
> demonstrations with five repetitions, not reproductions of the original
> manuscript experiments. Original experiment files F1..F9 would be
> excluded unless separately approved under statement C. [AUTHOR
> CONFIRMATION REQUIRED: provenance, contributors, final scope, per-artifact
> rights, release approval, and verified publication identifiers.]

## C. Code plus original experiment data (only if provenance + rights approved)

> If authors confirm the provenance, manuscript mapping, hashes, and
> redistribution rights of each approved original experiment file, those
> files and approved code would be archived at [ZENODO_VERSION_DOI], version
> [RELEASE_VERSION], with repository-owned code under MIT and original
> experiment data under [DATA_LICENSE_OR_PERMISSIONS].
> The archive would list the exact included files and their SHA-256 hashes.
> Any missing or restricted inputs would be identified explicitly. Availability
> of inputs and successful decryption would not by themselves establish full
> reproduction of manuscript measurements. [AUTHOR CONFIRMATION REQUIRED:
> per-file rights, provenance, inclusion list, contributors, release approval,
> and verified publication identifiers.]

## Evidence limits to preserve in any final statement

- F1..F9 original/encrypted/decrypted files are locally available under
  `results/analysis result/File 1-MP4` through `File 9-EXE`. All nine
  original/decrypted hashes match; all 27 files were untracked on the audit
  date. Provenance and redistribution rights remain pending.
- Table 3 matches saved ori cell 1 stdout, but
  `FileAttachment.pdf_encrypted` and `COMNET-S-26-08200.pdf` are missing.
  Table 7 matches the saved TXT report (and its identical MD counterpart).
  These matches are evidence comparisons, not fresh experimental runs.
- Original environment/repetitions are unknown. Additional ori notebook
  source/output equality is not an independent replication. The additional
  Shift128 notebook uses a different pipeline; its Figure 7 mapping is
  unconfirmed.
- UCEF v1.0/v3.0 DOCX reports are available locally, but the tool,
  configuration and standalone CSV/XLSX/figure exports have not been located;
  embedded figures do not establish a reproducible plotting pipeline.
  Reported encrypted-F9 statistics differ from current full-file statistics;
  input hashes, sampling/segments, and preprocessing need confirmation.
- The reported divergence/bit-difference values describe a prefix comparison
  including a 12-byte header, not controlled avalanche testing. Differential
  and KPA tests were not executed; CPA resistance was not demonstrated.
- OMML equation text has been extracted; original derivations and assumptions
  for Tables 8/9 still need confirmation.

## Release conditions and fixed rules

- MIT license choice is confirmed by the repository maintainer/user on
  2026-10-08; the earlier blanket placeholder/no-rights statement is historical
  and superseded. MIT covers repository-owned code/docs/synthetic demo data,
  not automatic rights to third-party F1..F9, the manuscript, or UCEF reports.
  Per-artifact permissions and release approval remain separate requirements.
- Never invent repository URLs, version identifiers, DOI, licenses, or
  contributor approvals; never claim publication or complete reproduction
  without verification.
- Require an explicit inclusion allowlist/filter before packaging.
  `scripts/build_release.py` collects all `results/` without rights gating;
  its DOCX/`Zone.Identifier` assertion is not a rights/privacy safeguard.
  Removing those files alone could still include restricted material.
- Review notebook outputs and logs for passwords/keys and private data;
  exclude DOCX manuscripts/reports, secrets, and non-redistributable files.
  Do not reproduce existing experimental password values.
- The existing ZIP is a historical local candidate, with no
  `results/analysis result/` folder in its manifest. The earlier wording-only
  patch updated three member documents and checksums without adding research
  evidence. The parent-managed archive was selectively updated for MIT wording,
  not fully rebuilt with all current docs; archive/metadata edits are outside
  this docs-only change. Its existence does not establish approved release scope.
- README and the package-description copy now describe the audited local
  evidence. Verify their consistency with the approved scope before release.
