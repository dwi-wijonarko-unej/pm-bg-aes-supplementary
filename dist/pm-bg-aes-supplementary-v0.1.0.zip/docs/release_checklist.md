# Release Checklist (local candidate v0.1.0 — NOT an approved public release)

Audit reference: [evidence audit dated 2026-10-08](evidence_audit.md).
The MIT license-choice gate is closed by the repository maintainer/user's
2026-10-08 confirmation; other gates remain unchecked. This is not verified
all-author approval or completion of release validation. External publication
has not been checked.

## Evidence and author confirmation

- [ ] Authors acknowledge open items in `docs/author_questions.md`; available
      evidence is not treated as resolved confirmation.
- [ ] Confirm selected ori cell 1 provenance and mapping to Tables 3/7.
      Table 3 saved stdout matches 0.0070 s, 14.27 MiB/s, 1125.57 KB, 99.9%,
      and 104300 → 104267 bytes; `FileAttachment.pdf_encrypted` and
      `COMNET-S-26-08200.pdf` remain missing.
- [ ] Confirm Table 7 input/protocol mapping: all rows match
      `results/analysis result/2. File TXT - Paper PM-BG + AES_ori.txt`, with
      identical `File TXT - Paper PM-BG + AES_ori.md` content in that directory.
- [ ] Confirm original environment and repetition counts; do not present
      DEMO-001..DEMO-011's five repetitions as the original protocol.
- [ ] Confirm provenance, manuscript mapping, hashes, and per-file rights for
      F1..F9. The 27 local original/encrypted/decrypted files under
      `results/analysis result/File 1-MP4` through `File 9-EXE` were untracked;
      nine matching original/decrypted hashes do not establish release rights.
- [ ] Confirm additional notebook roles: additional ori source/output is
      identical to root ori (metadata differs), not an independent run. The
      additional Shift128 notebook uses ±128 modulo 256 in a different
      complete-graph/unimodular/AES-128 whole-payload pipeline, not the selected
      permutation/AES-256 tail pipeline.
- [ ] Resolve Figure 7 mapping, including F9 N = 5,423,488, n = 32, and zero
      plaintext residual; do not infer its Figure 7 role from local file presence.
- [ ] Obtain UCEF tool/configuration, CSV/XLSX exports, and figure workflow,
      or label scores report-only. Local DOCX reports v1.0 (score 60) and v3.0
      are not independent analyzer reproduction.
- [ ] Reconcile encrypted-F9 report statistics (entropy 6.910008, chi-square
      12468952.264704, adjacent r ≈ 0.000917) with full-file values
      (6.910783258, 33766723.685766, 0.289727746) using input hashes, sampling,
      segments, and preprocessing.
- [ ] Label divergence 89.417345% and bit difference 42.830370% as an
      original/ciphertext prefix comparison including the 12-byte header, not
      controlled avalanche testing. Differential/KPA were not executed and CPA
      resistance was not demonstrated; require evidence for any retained claims.
- [ ] Confirm original derivations and assumptions for Tables 8/9. OMML text
      is extracted; earlier plain-text blanks do not imply unavailable equations.

## Rights, privacy, and release scope — mandatory before rebuild

- [x] MIT license choice confirmed by the repository maintainer/user on
      2026-10-08: "Lisensi kami gunakan MIT" (Q6). Covers repository-owned
      code, documentation, and synthetic demo data; all-author approval is
      not verified. The earlier pending-license finding is historical and
      superseded, not the current licensing status.
- [ ] Complete per-artifact ownership/redistribution review; MIT does not
      automatically cover third-party F1..F9, the manuscript, or UCEF/supplied
      reports. License choice does not establish provenance or publication
      approval.
- [ ] Confirm contributors, citation metadata, contact, and optional ORCIDs;
      `CITATION.cff` and `.zenodo.json` remain draft until approved.
- [ ] Obtain explicit author approval BEFORE any push/release/deposit (Q9).
- [ ] Approve an explicit per-file inclusion allowlist and implement/enforce
      an inclusion filter before building. `scripts/build_release.py` currently
      collects all `results/` without rights gating. Its DOCX/`Zone.Identifier`
      assertion is insufficient: deleting those alone could package restricted
      files. Do not rebuild using that behavior as-is.
- [ ] Review notebook outputs/logs, CSVs, figures, and all included files for
      passwords, keys, private information, and unauthorized data. Do not copy
      existing experimental password values into public artifacts.
- [ ] Exclude DOCX manuscripts/reports, `Zone.Identifier`, `.venv`, `.git`,
      caches, secrets, and non-redistributable material from the archive.
- [ ] Verify README and its package-description copy remain consistent with
      the approved evidence and actual release scope; the wording cleanup
      does not imply provenance or publication approval.

## Validation of an approved candidate

- [ ] `python scripts/reproduce_all.py --config configs/demo.yaml` green;
      describe its output as demonstration validation, not full manuscript
      reproduction.
- [ ] `pytest` green; `results/logs/test_report.txt` stored and privacy-reviewed.
- [ ] `notebooks/original/*.ipynb` checksum-identical to intended workspace
      sources; distinguish whole-file checksums from source/output equivalence
      where metadata differs.
- [ ] No fake DOI / repository URL / Zenodo URL; placeholders remain until
      verified identifiers exist.
- [ ] Rebuild only after rights, inclusion-filter, privacy, and approval gates
      pass. The existing ZIP is a historical candidate, has no
      `results/analysis result/` folder in its manifest. The earlier wording-only
      patch updated three archived documents and checksums. The parent-managed
      archive was selectively updated for MIT wording, not fully rebuilt or
      synchronized with all current docs. Archive/metadata handling is outside
      this docs-only change; no supplied evidence files were added.
- [ ] `dist/release_manifest.csv` lists every approved archived file with
      SHA-256 and matches the approved inclusion list.
- [ ] `dist/artifact_checksums.sha256` verifies (`sha256sum -c`).
- [ ] `dist/pm-bg-aes-supplementary-v0.1.0.zip` exists, is non-empty, and its
      content equals the reviewed manifest; existence alone is not approval.
- [ ] Select an appropriate conditional availability statement and finalize
      it only after actual publication/availability is verified; never claim
      all manuscript results were reproduced on the basis of this audit.

Post-approval only: create the approved GitHub repository → push → tag the
approved release version → make the approved Zenodo deposit → record real
URLs/DOI in metadata and rebuild/revalidate the archive as needed. No step
here is authorized merely by editing this checklist.
